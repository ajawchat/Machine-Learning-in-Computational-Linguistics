Submission for Assignment 3

Team members:
Ajinkya Awchat
Sumit Samant
Alka Nelapati